# Apex Roofing — Whop Website Template

Production-ready template for a US roofing company built for **Whop Websites**.

Designed so you can pitch real roofing businesses: deposit → job → final invoice flow, Payment Elements, Leads API, and pixel events.

## What is included

| Feature | Implementation |
|--------|----------------|
| Site sections | Services, Pricing, Financing, Service area, Reviews/trust, Contact/Estimate form |
| Plans | Inspection ($149), Project deposit ($500), Flat-rate service |
| Checkout | Whop Payment Elements (`Checkout` + `CheckoutElement` + `ExpressCheckoutElement` + **required** `BrandingElement`) |
| Financing | Surfaces automatically (Klarna, Afterpay, Splitit, etc.) for approved merchants |
| Estimate form | Posts to `/api/leads` → Whop Leads API |
| Card-on-file | Deposit checkout; final balance via Whop Invoices API |
| Pixel events | `estimate_requested`, `service_viewed`, `deposit_started` (+ automatic page views & checkout events on whop.site) |
| Config-driven | Change company name, services, prices, plan IDs in one file |

## Quick start with Whop AI or CLI

### Option A — Whop AI (recommended for speed)

1. Go to your Whop dashboard → **Websites** → **New website** → describe or paste this repo.
2. Or open Whop AI and say:  
   “Deploy this roofing template as a website. Use the code from the Apex Roofing template. Create three one-time plans: Inspection $149, Project Deposit $500, Standard Shingle Replacement $8900. Wire the estimate form to Leads API.”
3. Replace plan IDs in `src/lib/config.ts` with the real `plan_…` IDs Whop creates.
4. Promote the build. You get a live `*.whop.site` URL.

### Option B — Whop CLI

```bash
# Install CLI
curl -fsSL https://whop.com/install.sh | sh
whop   # sign in, select business

# Scaffold or link
whop apps init --app_type website --name "Apex Roofing" --domain apex-roofing
# then copy these source files into the project, or:
# whop apps pull --app app_xxx   (if you already created the app)

cd apex-roofing
npm install

# Add the Whop Vite plugin (required for deploy)
# In vite.config.ts:
#   import { whop } from "@whop/cli/vite";
#   plugins: [react(), whop()]

# Create plans in dashboard (or via API) and paste IDs into src/lib/config.ts

whop apps dev     # local with injected API key
whop apps deploy  # live
```

## Configure for a client

Edit **only** `src/lib/config.ts`:

- `company` — name, phone, email, address, stats
- `serviceArea` — cities
- `plans` — titles, prices, and especially the real `plan_…` / `prod_…` IDs
- `services`, `reviews`, `trustBadges`

No structural code changes needed.

## Create the three plans

In Whop dashboard (or API):

1. **Roof Inspection** — one-time, $149  
2. **Project Deposit** — one-time, $500 (this is the one that should save the payment method for later invoices)  
3. **Standard Shingle Replacement (up to 20 sq)** — one-time, $8,900  

Copy each variant ID (`plan_…`) into `src/lib/config.ts`.

## Server routes (Leads + Invoices)

On Whop Websites the runtime injects `WHOP_API_KEY` / signed requests. Example handlers:

### `POST /api/leads` (estimate form)

```ts
// Pseudo-code — adapt to your server framework (Hono, Nitro, etc.)
import { WhopClient } from "@whop/sdk";

export async function POST(req: Request) {
  const body = await req.json();
  const client = new WhopClient({ token: process.env.WHOP_API_KEY! });

  const lead = await client.leads.create({
    account_id: process.env.WHOP_ACCOUNT_ID!, // biz_…
    metadata: {
      name: body.name,
      email: body.email,
      phone: body.phone,
      address: body.address,
      service: body.service,
      notes: body.notes,
      source: "website_estimate_form",
    },
  });

  return Response.json({ id: lead.id });
}
```

### Final balance invoice (after job complete)

```ts
// Create + issue an invoice that can auto-charge the card on file
const invoice = await client.invoices.create({
  account_id: "biz_…",
  email_address: customerEmail,
  customer_name: customerName,
  items: [{ variant_id: "plan_…", quantity: 1 }], // or custom amount line items
  payment_method_id: savedPaymentMethodId, // payt_… from the deposit
  // due_at, memo, metadata…
});

await client.invoices.issue(invoice.id); // or whatever the issue endpoint is in current SDK
```

See current docs:  
https://docs.whop.com/developer/guides/invoices  
https://docs.whop.com/api-reference/leads/create-lead  
https://docs.whop.com/developer/guides/save-payment-methods

## Pixel events

- Automatic on `whop.site` / `whop.app`: page views, checkout views, purchases  
- Custom (already wired):
  - `service_viewed` — Services section mount  
  - `deposit_started` — when user clicks a pricing CTA  
  - `estimate_requested` — successful estimate form submit  

Verify in Whop dashboard → pixel / websites analytics (~1 min delay).

## Test checkout

1. Deploy to a Whop Website (sandbox or production).  
2. Use test card `4242 4242 4242 4242` (any future expiry / CVC) in sandbox.  
3. Confirm BrandingElement is present (required).  
4. Complete a deposit checkout and confirm the payment method is saved.  
5. Submit the estimate form and confirm a Lead appears.  
6. Create a test invoice for the balance and charge/send it.

## Project structure

```
src/
  lib/config.ts          ← all client-specific content & plan IDs
  components/
    Header.tsx
    Hero.tsx
    Services.tsx
    Pricing.tsx
    CheckoutPanel.tsx    ← Whop Elements
    Financing.tsx
    ServiceArea.tsx
    Reviews.tsx
    EstimateForm.tsx     ← Leads API
    Footer.tsx
  App.tsx
  main.tsx
  styles/global.css
```

## Whop features implemented

Whop Websites hosting, Payment Elements (CheckoutElement + ExpressCheckoutElement + BrandingElement), automatic financing options, Leads API for quote requests, setup-intent / card-on-file pattern for deposits, Invoices API for final balance, and custom `whop.track` events (`estimate_requested`, `service_viewed`, `deposit_started`). Page views and checkout conversion events are automatic on the hosted domain.

## License

Template is original and free to use for client pitches and production sites. Replace branding and plan IDs before going live with a real business.
