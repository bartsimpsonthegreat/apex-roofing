import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// For Whop Websites: when you run `whop apps init` or link the project,
// add the Whop Vite plugin: import { whop } from "@whop/cli/vite";
// and include it in plugins: [react(), whop()]
// The plugin packs dist/ correctly for Whop hosting.

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
  },
});
