/**
 * Whop Payment Elements checkout
 * ------------------------------
 * Uses Checkout + CheckoutElement (or ExpressCheckoutElement) + BrandingElement.
 * Financing options (Klarna, Afterpay, Splitit, etc.) surface automatically
 * for approved merchants — no custom card forms.
 *
 * For deposit flow: after successful payment, the payment method is on file
 * and can be charged later via the Invoices API (see server examples in README).
 */

import { useEffect, useState } from "react";
import {
  WhopElements,
  Checkout,
  CheckoutElement,
  ExpressCheckoutElement,
  BrandingElement,
} from "@whop/elements-react";
import { loadWhop } from "@whop/elements";

type Props = {
  planId: string;
  planTitle: string;
  price: number;
  isDeposit?: boolean;
};

export function CheckoutPanel({ planId, planTitle, price, isDeposit }: Props) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Elements load asynchronously
    setReady(true);
  }, []);

  // Placeholder IDs will fail — replace with real plan_… from your Whop dashboard
  const isPlaceholder = planId.includes("REPLACE_ME");

  if (isPlaceholder) {
    return (
      <div
        style={{
          padding: "1.25rem",
          background: "var(--color-surface-2)",
          borderRadius: "var(--radius)",
          border: "1px dashed var(--color-border)",
        }}
      >
        <p style={{ margin: "0 0 0.75rem", fontWeight: 600 }}>Connect your Whop plans</p>
        <p style={{ margin: 0, color: "var(--color-text-muted)", fontSize: "0.9rem" }}>
          Open <code>src/lib/config.ts</code> and replace the plan IDs with real{" "}
          <code>plan_…</code> values from your Whop dashboard. Then this panel will render live
          Payment Elements (including Apple Pay / Google Pay and financing options).
        </p>
        <p style={{ margin: "0.75rem 0 0", fontSize: "0.85rem", color: "var(--color-text-muted)" }}>
          Plan: {planTitle} · ${price.toLocaleString()}
          {isDeposit && " · Card will be saved for final invoice"}
        </p>
      </div>
    );
  }

  if (!ready) {
    return <p style={{ color: "var(--color-text-muted)" }}>Loading secure checkout…</p>;
  }

  return (
    <div>
      {error && (
        <p style={{ color: "#f87171", marginBottom: "0.75rem", fontSize: "0.9rem" }}>{error}</p>
      )}
      <WhopElements elements={loadWhop()}>
        <Checkout
          plan={planId}
          returnUrl={typeof window !== "undefined" ? `${window.location.origin}/?paid=1` : undefined}
          onComplete={(completion) => {
            if (completion.result === "payment") {
              // Fulfillment should come from payment.succeeded webhook, not the browser.
              console.log("Payment completed", completion);
            }
          }}
          onError={(err) => setError(err?.message || "Checkout error")}
        >
          {/* Express wallets (Apple Pay / Google Pay) */}
          <div style={{ marginBottom: "1rem" }}>
            <ExpressCheckoutElement layout="horizontal" />
          </div>

          {/* Full checkout surface */}
          <CheckoutElement />

          {/* Required — other elements stay loading until BrandingElement mounts */}
          <BrandingElement />
        </Checkout>
      </WhopElements>
      {isDeposit && (
        <p style={{ marginTop: "1rem", fontSize: "0.85rem", color: "var(--color-text-muted)" }}>
          Your card is saved securely. After the job is complete we will send a final invoice
          that can auto-charge the card on file or be paid manually.
        </p>
      )}
    </div>
  );
}
