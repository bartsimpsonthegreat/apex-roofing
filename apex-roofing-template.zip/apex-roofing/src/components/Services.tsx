import { useEffect } from "react";
import { services } from "../lib/config";

const icons: Record<string, string> = {
  wrench: "🔧",
  home: "🏠",
  search: "🔍",
};

export function Services() {
  useEffect(() => {
    // Fire when services section is viewed
    if (typeof window !== "undefined" && window.whop?.track) {
      window.whop.track("service_viewed", { section: "services" });
    }
  }, []);

  return (
    <section id="services" className="section">
      <div className="container">
        <h2 className="section-title">What we do</h2>
        <p className="section-sub">
          From emergency leak repairs to full replacements, we handle residential and light commercial roofs.
        </p>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {services.map((s) => (
            <article key={s.id} className="card">
              <div style={{ fontSize: "1.75rem", marginBottom: "0.75rem" }}>{icons[s.icon] || "•"}</div>
              <h3 style={{ margin: "0 0 0.5rem", fontSize: "1.2rem" }}>{s.title}</h3>
              <p style={{ margin: 0, color: "var(--color-text-muted)", fontSize: "0.95rem" }}>{s.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
