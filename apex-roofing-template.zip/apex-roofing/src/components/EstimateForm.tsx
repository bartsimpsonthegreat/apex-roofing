import { useState, FormEvent } from "react";
import { company } from "../lib/config";

/**
 * Request an Estimate → Whop Leads API
 * ------------------------------------
 * On Whop Websites the runtime injects a server-side API key, so you can call
 * the Leads endpoint from a server route / API handler without exposing secrets.
 *
 * For local preview this form posts to /api/leads (you implement the handler
 * when deploying, or use Whop AI to wire it).
 */

type Status = "idle" | "loading" | "success" | "error";

export function EstimateForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("loading");
    setMessage("");

    const form = e.currentTarget;
    const data = new FormData(form);
    const payload = {
      name: String(data.get("name") || ""),
      email: String(data.get("email") || ""),
      phone: String(data.get("phone") || ""),
      address: String(data.get("address") || ""),
      service: String(data.get("service") || ""),
      notes: String(data.get("notes") || ""),
    };

    try {
      // On a real Whop Website this hits your server route that calls:
      // POST https://api.whop.com/api/v1/leads
      // with account_id + metadata (name, email, phone, address, service, notes)
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        // Fallback for local / demo: still show success and fire the pixel
        console.warn("Leads API not yet wired — demo mode");
      }

      if (typeof window !== "undefined" && window.whop?.track) {
        window.whop.track("estimate_requested", {
          service: payload.service,
          value: 0,
          currency: "USD",
        });
      }

      setStatus("success");
      setMessage("Thanks! We'll contact you within one business day.");
      form.reset();
    } catch {
      setStatus("error");
      setMessage("Something went wrong. Please call us or try again.");
    }
  }

  return (
    <section id="estimate" className="section" style={{ background: "var(--color-surface)" }}>
      <div className="container" style={{ maxWidth: 640 }}>
        <h2 className="section-title">Request a free estimate</h2>
        <p className="section-sub">
          Tell us about your roof. No obligation — we'll follow up with next steps and pricing.
        </p>

        <form onSubmit={handleSubmit} className="card" style={{ display: "grid", gap: "1rem" }}>
          <div style={{ display: "grid", gap: "0.35rem" }}>
            <label htmlFor="name" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
              Full name *
            </label>
            <input
              id="name"
              name="name"
              required
              placeholder="Jane Doe"
              style={inputStyle}
            />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
            <div style={{ display: "grid", gap: "0.35rem" }}>
              <label htmlFor="email" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
                Email *
              </label>
              <input id="email" name="email" type="email" required placeholder="you@email.com" style={inputStyle} />
            </div>
            <div style={{ display: "grid", gap: "0.35rem" }}>
              <label htmlFor="phone" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
                Phone *
              </label>
              <input id="phone" name="phone" type="tel" required placeholder="(555) 000-0000" style={inputStyle} />
            </div>
          </div>

          <div style={{ display: "grid", gap: "0.35rem" }}>
            <label htmlFor="address" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
              Property address *
            </label>
            <input id="address" name="address" required placeholder="123 Main St, Atlanta, GA" style={inputStyle} />
          </div>

          <div style={{ display: "grid", gap: "0.35rem" }}>
            <label htmlFor="service" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
              Service needed
            </label>
            <select id="service" name="service" style={inputStyle} defaultValue="inspection">
              <option value="inspection">Roof Inspection</option>
              <option value="repair">Roof Repair</option>
              <option value="replacement">Roof Replacement</option>
              <option value="other">Other / Not sure</option>
            </select>
          </div>

          <div style={{ display: "grid", gap: "0.35rem" }}>
            <label htmlFor="notes" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
              Anything else we should know?
            </label>
            <textarea
              id="notes"
              name="notes"
              rows={3}
              placeholder="Leak near chimney, storm damage, age of current roof…"
              style={{ ...inputStyle, resize: "vertical" }}
            />
          </div>

          <button className="btn btn-primary" type="submit" disabled={status === "loading"} style={{ marginTop: "0.25rem" }}>
            {status === "loading" ? "Sending…" : "Request Estimate"}
          </button>

          {message && (
            <p
              style={{
                margin: 0,
                fontSize: "0.9rem",
                color: status === "success" ? "var(--color-success)" : "#f87171",
              }}
            >
              {message}
            </p>
          )}

          <p style={{ margin: 0, fontSize: "0.8rem", color: "var(--color-text-muted)" }}>
            Prefer to talk? Call {company.phone}
          </p>
        </form>
      </div>
    </section>
  );
}

const inputStyle: React.CSSProperties = {
  padding: "0.7rem 0.9rem",
  borderRadius: 8,
  border: "1px solid var(--color-border)",
  background: "var(--color-bg)",
  color: "var(--color-text)",
  outline: "none",
};
