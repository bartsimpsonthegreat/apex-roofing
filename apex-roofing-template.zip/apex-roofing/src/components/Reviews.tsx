import { reviews, trustBadges, company } from "../lib/config";

export function Reviews() {
  return (
    <section className="section">
      <div className="container">
        <h2 className="section-title">Trusted by homeowners</h2>
        <p className="section-sub">
          {company.rating} average from {company.reviewCount}+ verified reviews.
        </p>

        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "0.6rem",
            marginBottom: "2rem",
          }}
        >
          {trustBadges.map((b) => (
            <span
              key={b}
              style={{
                padding: "0.4rem 0.85rem",
                background: "var(--color-surface)",
                borderRadius: "999px",
                border: "1px solid var(--color-border)",
                fontSize: "0.8rem",
                fontWeight: 500,
              }}
            >
              {b}
            </span>
          ))}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {reviews.map((r) => (
            <blockquote key={r.name} className="card" style={{ margin: 0 }}>
              <div style={{ color: "var(--color-accent)", marginBottom: "0.5rem" }}>
                {"★".repeat(r.rating)}
              </div>
              <p style={{ margin: "0 0 1rem", fontSize: "0.95rem" }}>"{r.text}"</p>
              <footer style={{ color: "var(--color-text-muted)", fontSize: "0.85rem" }}>
                — {r.name}, {r.location}
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
