import { useState } from "react";
import { plans } from "../lib/config";
import { CheckoutPanel } from "./CheckoutPanel";

export function Pricing() {
  const [selected, setSelected] = useState<"inspection" | "deposit" | "flatRate" | null>(null);

  const items = [
    { key: "inspection" as const, plan: plans.inspection, badge: "Popular" },
    { key: "deposit" as const, plan: plans.deposit, badge: "Starts your project" },
    { key: "flatRate" as const, plan: plans.flatRate, badge: "Fixed price" },
  ];

  return (
    <section id="pricing" className="section" style={{ background: "var(--color-surface)" }}>
      <div className="container">
        <h2 className="section-title">Transparent pricing</h2>
        <p className="section-sub">
          Book an inspection, put down a deposit to lock your schedule, or choose a flat-rate package.
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.25rem",
            marginBottom: selected ? "2rem" : 0,
          }}
        >
          {items.map(({ key, plan, badge }) => (
            <article
              key={key}
              className="card"
              style={{
                display: "flex",
                flexDirection: "column",
                borderColor: selected === key ? "var(--color-accent)" : undefined,
              }}
            >
              <span
                style={{
                  fontSize: "0.75rem",
                  fontWeight: 600,
                  color: "var(--color-accent)",
                  textTransform: "uppercase",
                  letterSpacing: "0.04em",
                }}
              >
                {badge}
              </span>
              <h3 style={{ margin: "0.5rem 0 0.25rem", fontSize: "1.25rem" }}>{plan.title}</h3>
              <p style={{ margin: "0 0 1rem", color: "var(--color-text-muted)", fontSize: "0.9rem", flex: 1 }}>
                {plan.description}
              </p>
              <div style={{ fontSize: "1.75rem", fontWeight: 700, marginBottom: "1rem" }}>
                ${plan.price.toLocaleString()}
                <span style={{ fontSize: "0.9rem", fontWeight: 400, color: "var(--color-text-muted)" }}>
                  {" "}
                  one-time
                </span>
              </div>
              <button
                className="btn btn-primary"
                style={{ width: "100%" }}
                onClick={() => {
                  setSelected(key);
                  if (typeof window !== "undefined" && window.whop?.track) {
                    window.whop.track("deposit_started", {
                      plan: key,
                      plan_id: plan.id,
                      value: plan.price,
                      currency: "USD",
                    });
                  }
                }}
              >
                {key === "deposit" ? "Pay Deposit" : key === "inspection" ? "Book Inspection" : "Purchase"}
              </button>
            </article>
          ))}
        </div>

        {selected && (
          <div className="card" style={{ maxWidth: 520, margin: "0 auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
              <h3 style={{ margin: 0 }}>Checkout — {plans[selected].title}</h3>
              <button
                onClick={() => setSelected(null)}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "var(--color-text-muted)",
                  cursor: "pointer",
                  fontSize: "1.25rem",
                }}
              >
                ×
              </button>
            </div>
            <CheckoutPanel
              planId={plans[selected].id}
              planTitle={plans[selected].title}
              price={plans[selected].price}
              isDeposit={selected === "deposit"}
            />
          </div>
        )}
      </div>
    </section>
  );
}
