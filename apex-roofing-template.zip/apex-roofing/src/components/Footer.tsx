import { company } from "../lib/config";

export function Footer() {
  return (
    <footer
      style={{
        borderTop: "1px solid var(--color-border)",
        padding: "2.5rem 0",
        color: "var(--color-text-muted)",
        fontSize: "0.9rem",
      }}
    >
      <div
        className="container"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1.5rem",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        <div>
          <div style={{ fontWeight: 700, color: "var(--color-text)", marginBottom: "0.35rem" }}>
            {company.name}
          </div>
          <div>{company.address}</div>
          <div>{company.city}</div>
        </div>
        <div>
          <div>{company.phone}</div>
          <div>{company.email}</div>
        </div>
        <div style={{ maxWidth: 280 }}>
          Licensed & insured roofing contractor. This is a Whop Website template for demonstration.
        </div>
      </div>
      <div className="container" style={{ marginTop: "1.5rem", fontSize: "0.8rem" }}>
        © {new Date().getFullYear()} {company.name}. All rights reserved.
      </div>
    </footer>
  );
}
