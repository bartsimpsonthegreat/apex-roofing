import { serviceArea, company } from "../lib/config";

export function ServiceArea() {
  return (
    <section className="section" style={{ background: "var(--color-surface)" }}>
      <div className="container">
        <h2 className="section-title">Service area</h2>
        <p className="section-sub">
          Proudly serving metro {company.city.split(",")[0]} and nearby communities.
        </p>
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "0.6rem",
          }}
        >
          {serviceArea.map((city) => (
            <span
              key={city}
              style={{
                padding: "0.5rem 1rem",
                background: "var(--color-bg)",
                borderRadius: "999px",
                border: "1px solid var(--color-border)",
                fontSize: "0.9rem",
              }}
            >
              {city}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
