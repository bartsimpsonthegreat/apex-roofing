export function Financing() {
  return (
    <section className="section">
      <div className="container">
        <div
          className="card"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "2rem",
            alignItems: "center",
            background: "linear-gradient(135deg, #1a2332 0%, #243044 100%)",
          }}
        >
          <div>
            <h2 className="section-title" style={{ marginBottom: "0.75rem" }}>
              Flexible financing
            </h2>
            <p style={{ color: "var(--color-text-muted)", margin: "0 0 1rem" }}>
              Spread the cost of a new roof with monthly payments. Klarna, Afterpay, Splitit and
              other options appear automatically at checkout for approved merchants — no extra
              setup required when you use Whop Payment Elements.
            </p>
            <ul style={{ margin: 0, paddingLeft: "1.2rem", color: "var(--color-text-muted)" }}>
              <li>0% promotional APR options available*</li>
              <li>Decision in minutes</li>
              <li>No impact to apply for many lenders</li>
            </ul>
          </div>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: "0.75rem",
              justifyContent: "center",
            }}
          >
            {["Klarna", "Afterpay", "Splitit", "Affirm"].map((name) => (
              <span
                key={name}
                style={{
                  padding: "0.6rem 1.1rem",
                  background: "var(--color-bg)",
                  borderRadius: "999px",
                  border: "1px solid var(--color-border)",
                  fontWeight: 600,
                  fontSize: "0.9rem",
                }}
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
