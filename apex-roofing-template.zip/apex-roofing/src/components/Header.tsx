import { company } from "../lib/config";

export function Header() {
  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 50,
        background: "rgba(15, 20, 25, 0.92)",
        backdropFilter: "blur(12px)",
        borderBottom: "1px solid var(--color-border)",
      }}
    >
      <div
        className="container"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 64,
          gap: "1rem",
        }}
      >
        <a href="#" style={{ fontWeight: 700, fontSize: "1.15rem", letterSpacing: "-0.02em" }}>
          {company.name}
        </a>
        <nav style={{ display: "flex", gap: "1.25rem", alignItems: "center" }}>
          <a href="#services" className="nav-link" style={{ color: "var(--color-text-muted)", fontSize: "0.9rem" }}>
            Services
          </a>
          <a href="#pricing" className="nav-link" style={{ color: "var(--color-text-muted)", fontSize: "0.9rem" }}>
            Pricing
          </a>
          <a href="#estimate" className="btn btn-primary" style={{ padding: "0.55rem 1.1rem", fontSize: "0.9rem" }}>
            Free Estimate
          </a>
        </nav>
      </div>
    </header>
  );
}
