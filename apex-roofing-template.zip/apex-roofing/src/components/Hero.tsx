import { company } from "../lib/config";

export function Hero() {
  return (
    <section
      style={{
        padding: "5rem 0 4rem",
        background: "linear-gradient(180deg, #1a2332 0%, var(--color-bg) 100%)",
      }}
    >
      <div className="container" style={{ display: "grid", gap: "2rem", alignItems: "center" }}>
        <div style={{ maxWidth: 640 }}>
          <p
            style={{
              color: "var(--color-accent)",
              fontWeight: 600,
              fontSize: "0.9rem",
              textTransform: "uppercase",
              letterSpacing: "0.06em",
              margin: "0 0 0.75rem",
            }}
          >
            {company.tagline}
          </p>
          <h1
            style={{
              fontSize: "clamp(2.1rem, 5vw, 3.25rem)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              lineHeight: 1.15,
              margin: "0 0 1.25rem",
            }}
          >
            Roof repair & replacement you can trust
          </h1>
          <p style={{ color: "var(--color-text-muted)", fontSize: "1.1rem", margin: "0 0 1.75rem" }}>
            Licensed crews, clear pricing, and financing options. Serving {company.city.split(",")[0]} and surrounding
            communities for {company.yearsInBusiness} years.
          </p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.75rem" }}>
            <a href="#estimate" className="btn btn-primary">
              Request Free Estimate
            </a>
            <a href="#pricing" className="btn btn-secondary">
              View Services & Pricing
            </a>
          </div>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: "1.5rem",
              marginTop: "2.5rem",
              color: "var(--color-text-muted)",
              fontSize: "0.9rem",
            }}
          >
            <span>
              <strong style={{ color: "var(--color-text)" }}>{company.rating}★</strong> from{" "}
              {company.reviewCount}+ reviews
            </span>
            <span>
              <strong style={{ color: "var(--color-text)" }}>{company.projectsCompleted}</strong> projects
            </span>
            <span>
              <strong style={{ color: "var(--color-text)" }}>{company.yearsInBusiness}+</strong> years
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
