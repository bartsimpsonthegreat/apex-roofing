import { useEffect } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { Financing } from "./components/Financing";
import { ServiceArea } from "./components/ServiceArea";
import { Reviews } from "./components/Reviews";
import { Pricing } from "./components/Pricing";
import { EstimateForm } from "./components/EstimateForm";
import { Footer } from "./components/Footer";
import { company } from "./lib/config";

declare global {
  interface Window {
    whop?: {
      track: (event: string, props?: Record<string, unknown>) => void;
    };
  }
}

export default function App() {
  useEffect(() => {
    // Page view is automatic on whop.site / whop.app.
    // Custom events are fired from components.
    document.title = `${company.name} | Repair • Replacement • Inspection`;
  }, []);

  return (
    <>
      <Header />
      <main>
        <Hero />
        <Services />
        <Pricing />
        <Financing />
        <ServiceArea />
        <Reviews />
        <EstimateForm />
      </main>
      <Footer />
    </>
  );
}
