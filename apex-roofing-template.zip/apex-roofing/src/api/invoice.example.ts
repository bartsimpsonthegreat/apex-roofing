/**
 * Example: create and issue a final-balance invoice after the job.
 * Prefer attaching the payment_method_id saved from the deposit checkout
 * so Whop can auto-charge (or the customer can pay the invoice link).
 *
 * Docs: https://docs.whop.com/developer/guides/invoices
 */

import { WhopClient } from "@whop/sdk";

export async function createFinalInvoice(opts: {
  email: string;
  customerName: string;
  amountCents?: number; // if using ad-hoc amount
  variantId?: string;   // or a plan/variant
  paymentMethodId?: string; // payt_… from deposit
  memo?: string;
}) {
  const client = new WhopClient({
    token: process.env.WHOP_API_KEY!,
  });

  // Shape depends on current API version — check docs for exact fields.
  const invoice = await client.invoices.create({
    account_id: process.env.WHOP_ACCOUNT_ID!,
    email_address: opts.email,
    customer_name: opts.customerName,
    items: opts.variantId
      ? [{ variant_id: opts.variantId, quantity: 1 }]
      : undefined,
    payment_method_id: opts.paymentMethodId,
    memo: opts.memo || "Final balance for completed roofing work.",
  } as any);

  // Issue / send
  // await client.invoices.issue(invoice.id);
  return invoice;
}
