/**
 * Example server handler for the estimate form.
 * On Whop Websites, adapt this to your framework's route style
 * (the injected runtime provides the API key).
 *
 * Docs: https://docs.whop.com/api-reference/leads/create-lead
 */

import { WhopClient } from "@whop/sdk";

export async function createLead(body: {
  name: string;
  email: string;
  phone: string;
  address: string;
  service: string;
  notes?: string;
}) {
  const client = new WhopClient({
    token: process.env.WHOP_API_KEY!,
  });

  const lead = await client.leads.create({
    account_id: process.env.WHOP_ACCOUNT_ID!, // biz_…
    metadata: {
      name: body.name,
      email: body.email,
      phone: body.phone,
      address: body.address,
      service: body.service,
      notes: body.notes || "",
      source: "website_estimate_form",
    },
  });

  return lead;
}
