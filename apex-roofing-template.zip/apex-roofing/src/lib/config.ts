/**
 * Apex Roofing — Whop Website Template Config
 * ============================================
 * Swap company name, services, pricing, and plan IDs here.
 * No structural changes needed for a new roofing client.
 */

export const company = {
  name: "Apex Roofing",
  tagline: "Protecting Homes Across the Southeast",
  phone: "(555) 014-7623",
  email: "hello@apexroofing.example",
  address: "1240 Ridgeway Blvd, Suite 200",
  city: "Atlanta, GA 30309",
  yearsInBusiness: 18,
  projectsCompleted: "4,200+",
  rating: 4.9,
  reviewCount: 860,
};

export const serviceArea = [
  "Atlanta",
  "Marietta",
  "Roswell",
  "Alpharetta",
  "Sandy Springs",
  "Decatur",
  "Smyrna",
  "Brookhaven",
];

/**
 * Whop plan / product IDs
 * Create these in your Whop dashboard (or via API) then paste the IDs.
 * plan_… for variants, prod_… for products.
 */
export const plans = {
  inspection: {
    id: "plan_INSPECTION_REPLACE_ME",       // $149 one-time inspection
    productId: "prod_INSPECTION_REPLACE_ME",
    title: "Roof Inspection",
    price: 149,
    description: "Professional inspection with detailed report and photo documentation.",
  },
  deposit: {
    id: "plan_DEPOSIT_REPLACE_ME",          // $500 project deposit (saves card for final invoice)
    productId: "prod_DEPOSIT_REPLACE_ME",
    title: "Project Deposit",
    price: 500,
    description: "Secure your spot on the calendar. Balance due on completion via invoice.",
  },
  flatRate: {
    id: "plan_FLATRATE_REPLACE_ME",         // Example flat-rate service
    productId: "prod_FLATRATE_REPLACE_ME",
    title: "Standard Shingle Replacement (up to 20 sq)",
    price: 8900,
    description: "Complete tear-off and install of architectural shingles, underlayment, and ridge vent.",
  },
};

export const services = [
  {
    id: "repair",
    title: "Roof Repair",
    description:
      "Leak fixes, storm damage, missing shingles, flashing, and valley repairs. Same-week service available.",
    icon: "wrench",
  },
  {
    id: "replacement",
    title: "Roof Replacement",
    description:
      "Full tear-off and re-roof with architectural or premium materials. Lifetime workmanship warranty.",
    icon: "home",
  },
  {
    id: "inspection",
    title: "Roof Inspection",
    description:
      "Thorough inspection with moisture readings, drone photos, and a written report you can share with insurance.",
    icon: "search",
  },
];

export const reviews = [
  {
    name: "Marcus T.",
    location: "Marietta, GA",
    text: "Apex replaced our entire roof after the last storm. On time, clean job site, and the crew was professional from start to finish.",
    rating: 5,
  },
  {
    name: "Sarah K.",
    location: "Alpharetta, GA",
    text: "They found issues our previous inspector missed. The detailed report helped us get the insurance claim approved quickly.",
    rating: 5,
  },
  {
    name: "James R.",
    location: "Roswell, GA",
    text: "Transparent pricing and financing options made a big project manageable. Highly recommend.",
    rating: 5,
  },
];

export const trustBadges = [
  "Licensed & Insured",
  "GA Roofing Contractor",
  "GAF Master Elite",
  "BBB A+",
  "Google 4.9★",
];
